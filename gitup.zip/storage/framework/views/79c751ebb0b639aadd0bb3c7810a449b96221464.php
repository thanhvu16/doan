<?php $__env->startSection('title',' Sản Phẩm'); ?>
<?php $__env->startSection('main'); ?>

    <!-- ========================================= MAIN ========================================= -->
    <main id="about-us">

        <section class="pt-40 pb-40 ">
            <div class="container">
                <div class="row" style="margin-top: 40px">
                    <div class="col-lg-12">
                        <div class="li-blog-single-item mb-30">
                            <div class="row">
                                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="col-md-6"  >
                                    <div class="col-lg-4" style="margin-top: 10px;">
                                        <div class="li-blog-banner">
                                            <a href="blog-details-left-sidebar.html"><img class="img-responsive"  src="<?php echo e(asset('../storage/app/public/upload/blog/'.$blog->imges)); ?>" alt=""></a>
                                        </div>
                                    </div>
                                    <div class="col-lg-8" style="margin-top: 10px;">
                                        <div class="li-blog-content">
                                            <div class="li-blog-details">
                                                <h3><a href="<?php echo e(route('blogchitiet',$blog->id)); ?>" style="font-size: 18px;color: black"><?php echo e($blog->tiles); ?></a></h3>
                                                <div class="li-blog-meta">
                                                    <a class="post-time" style="font-size: 12px;color: black" href="<?php echo e(route('blogchitiet',$blog->id)); ?>"><i class="fa fa-calendar"></i>  <?php echo e(date('d/m/Y',strtotime( $blog->date))); ?></a>
                                                </div>
                                                <p></p>
                                                <a class="read-more"  style="font-size: 14px;color: midnightblue;" href="<?php echo e(route('blogchitiet',$blog->id)); ?>">Xem Thêm...</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        </section>


    </main><!-- /#about-us -->
    <!-- ========================================= MAIN : END ========================================= -->
<?php $__env->stopSection(); ?>
    <!-- ============================================================= FOOTER ============================================================= -->

    <!-- ============================================================= FOOTER : END ============================================================= -->



<?php echo $__env->make('fontend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xamppp\htdocs\demoshop\resources\views/fontend/tintuc.blade.php ENDPATH**/ ?>