<?php $__env->startSection('title',' Sản Phẩm'); ?>
<?php $__env->startSection('main'); ?>

    <!-- ============================================================= TOP NAVIGATION : END ============================================================= -->

    <!-- ============================================================= HEADER ============================================================= -->

    <!-- ============================================================= HEADER : END ============================================================= -->

    <div id="top-banner-and-menu">
        <div class="container">
            <div class="col-xs-12 col-sm-4 col-md-3 sidemenu-holder">
                <!-- ================================== TOP NAVIGATION ================================== -->
                <div class="side-menu animate-dropdown">
                    <div class="head"><i class="fa fa-list"></i> Hãng Điện Thoại</div>
                    <nav class="yamm megamenu-horizontal" role="navigation">
                        <ul class="nav">
                            <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li class="dropdown menu-item"><a class="dropdown-toggle" data-toggle="dropdown" href="<?php echo e(route('detaicate',$cate->id)); ?>"><?php echo e($cate->cate_name); ?></a></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </ul><!-- /.nav -->
                    </nav><!-- /.megamenu-horizontal -->
                </div><!-- /.side-menu -->
                <!-- ================================== TOP NAVIGATION : END ================================== -->
            </div><!-- /.sidemenu-holder -->

            <div class="col-xs-12 col-sm-8 col-md-9 homebanner-holder">
                <!-- ========================================== SECTION – HERO ========================================= -->
                <div class="table-responsive">
                    <div class="dataTables_wrapper form-inline dt-bootstrap">
                        <table class="table table-bordered table-striped table-hover dataTable js-exportable">
                            <colgroup width="100%">
                                <col style="width: 5%;">
                                <col style="width: 50%;">
                                <col style="width: 25%;">
                                <col style="width: 20%;">

                            <thead>
                            <tr role="row">
                                <th>STT</th>
                                <th>Địa Chỉ</th>
                                <th>Điện Thoại</th>
                                <th>Thời GianLàm Việc</th>

                            </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $baohanh; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$itme): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr class="odd">
                                    <td>
                                       <?php echo e($key); ?>

                                    </td>
                                    <td>
                                       <?php echo e($itme->address); ?>

                                    </td>
                                    <td>
                                        <?php echo e($itme->phone); ?>

                                    </td>
                                    <td>
                                        <?php echo e($itme->time_work); ?>

                                    </td>

                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                        <!-- pagination -->

                    </div>
                </div>
                <!-- ========================================= SECTION – HERO : END ========================================= -->
            </div><!-- /.homebanner-holder -->
        </div><!-- /.container -->
    </div><!-- /#top-banner-and-menu -->

    <!-- ========================================= HOME BANNERS ========================================= -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('fontend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xamppp\htdocs\demoshop\resources\views/fontend/baohanh.blade.php ENDPATH**/ ?>