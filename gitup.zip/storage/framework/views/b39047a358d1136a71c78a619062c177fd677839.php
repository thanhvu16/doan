<?php $__env->startSection('title','Tìm Kiếm'); ?>
<?php $__env->startSection('main'); ?>
	<link rel="stylesheet" href="css/search.css">


					<div id="wrap-inner">
						<div class="products">
							<h3>Tìm kiếm với từ khóa: <span><?php echo e($seachpro); ?></span></h3>
							<div class="product-list row">
                                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data1): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="product-item col-md-3 col-sm-6 col-xs-12">
                                        <a href="#"><img  style="height: 173px" src="<?php echo e(asset('../storage/app/public/upload/'.$data1->pro_img)); ?>" class="img-thumbnail img-responsive"></a>
                                        <p style=" "><a href="#"><?php echo e($data1->pro_name); ?></a></p>
                                        <p class="price" ><?php echo e(number_format($data1->pro_price,0,',','.')); ?>đ</p>
                                        <a href="<?php echo e(route('detaipro', $data1->id)); ?>">Xem chi tiết</a>
                                        <div class="marsk">
                                            </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							</div>
						</div>

						<div id="pagination">
							<ul class="pagination pagination-lg justify-content-center">
								<?php echo e($data->links()); ?>

							</ul>
						</div>
					</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('fontend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xamppp\htdocs\demoshop\resources\views/fontend/search.blade.php ENDPATH**/ ?>