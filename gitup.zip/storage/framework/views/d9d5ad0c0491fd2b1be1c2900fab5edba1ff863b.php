<?php $__env->startSection('title',' Sản Phẩm'); ?>
<?php $__env->startSection('main'); ?>

    <!-- ============================================================= TOP NAVIGATION : END ============================================================= -->

    <!-- ============================================================= HEADER ============================================================= -->

    <!-- ============================================================= HEADER : END ============================================================= -->

    <div id="top-banner-and-menu">
        <div class="container">
            <div class="col-xs-12 col-sm-4 col-md-3 sidemenu-holder">
                <!-- ================================== TOP NAVIGATION ================================== -->
                <div class="side-menu animate-dropdown">
                    <div class="head"><i class="fa fa-list"></i> Hãng Điện Thoại</div>
                    <nav class="yamm megamenu-horizontal" role="navigation">
                        <ul class="nav">
                            <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li class="dropdown menu-item"><a class="dropdown-toggle" data-toggle="dropdown" href="<?php echo e(route('detaicate',$cate->id)); ?>"><?php echo e($cate->cate_name); ?></a></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </ul><!-- /.nav -->
                    </nav><!-- /.megamenu-horizontal -->
                </div><!-- /.side-menu -->
                <!-- ================================== TOP NAVIGATION : END ================================== -->
            </div><!-- /.sidemenu-holder -->


            <div class="col-xs-12 col-sm-8 col-md-9 homebanner-holder">
                 <form action="<?php echo e(route('tracuudonhang')); ?>" method="get">
                     <?php echo csrf_field(); ?>
                        <div class="billing-address">
                            <h2 class="border h1">Tra Cứu Đơn Hàng</h2>
                            <div class="row field-row">
                                <div class="col-xs-12">
                                    <label>Tìm kiếm</label>
                                    <input class="le-input" name="phone" required placeholder="nhập số điện thoại...">
                                </div>
                            </div><!-- /.field-row -->
                        </div><!-- /.billing-address -->
                     <div class="col-md-12 text-right" style="margin-top: 10px">
                         <button class="btn btn-danger">Tìm kiếm</button>
                     </div>
                </form><br>
                <!-- ========================================= SECTION – HERO : END ========================================= -->
                <?php if($donhang >0): ?>
                <div class="col-md-12" style="margin-top: 15px">
                    <table class="table table-bordered table-striped table-hover dataTable js-exportable" >
                        <thead>
                        <tr role="row">
                            <th>
                                STT
                            </th>
                            <th>
                                Tên Khách Hàng
                            </th>
                            <th>
                                Trạng thái
                            </th>


                        </tr>
                        </thead>
                        <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $donhang1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr class="odd">
                                <td>
                                    <?php echo e($key+1); ?>

                                </td>
                                <td>
                                    <?php echo e($data->ho_ten); ?>

                                </td>
                                <td>
                                    <?php if($data->stt =='1'): ?>
                                        <span class="label label-success">Nhận đơn</span>
                                    <?php elseif(($data->stt =='2')): ?>
                                        <span class="label label-warning">Xác nhận</span>
                                    <?php else: ?>
                                        <span class="label label-warning">Đã giao</span>
                                    <?php endif; ?>
                                </td>


                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            </tr>

                            <td colspan="8" class="text-center">Không có đơn hàng nào</td>
                        <?php endif; ?>
                        </tbody>
                    </table>
                </div>
                <?php else: ?>
                <div class="col-md-12 text-center">
                    <p style="color: red">Hiện Tại không có đơn hàng nào!Mời bạn nhập số điện thoại để tìm kiếm!!!</p>
                </div>
                <?php endif; ?>

            </div><!-- /.homebanner-holder -->



        </div><!-- /.container -->
    <!-- /#top-banner-and-menu -->
    </div>

    <!-- ========================================= HOME BANNERS ========================================= -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('fontend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xamppp\htdocs\gitup\resources\views/fontend/tracuudon.blade.php ENDPATH**/ ?>