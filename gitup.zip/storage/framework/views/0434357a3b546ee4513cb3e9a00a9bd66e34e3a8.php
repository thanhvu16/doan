<?php if(Session::has('erro')): ?>
    <p class="alert alert-danger"><?php echo e(Session::get('erro')); ?></p>
<?php endif; ?>
<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $erro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <p class="alert alert-danger"><?php echo e($erro); ?></p>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php /**PATH D:\xamppp\htdocs\gitup\resources\views/errors/note.blade.php ENDPATH**/ ?>