<?php $__env->startSection('title','Thành Viên'); ?>
<?php $__env->startSection('main'); ?>

    <div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">
        <div class="row">
            <div class="col-lg-12">
                <h1 class="page-header">Thêm Thành viên</h1>
            </div>
            <a href="<?php echo e(route('createmem')); ?>" class="btn bg-indigo waves-effect"
               role="button">
                <button class="btn-primary">THÊM THÀNH VIÊN</button>
            </a>
        </div><!--/.row-->

       <div class="row">
           <?php if($message = Session::get('success')): ?>
               <div class="alert alert-success">
                   <strong><?php echo e($message); ?></strong>
               </div>
           <?php endif; ?>
           <div class="table-responsive">
               <div  class="dataTables_wrapper form-inline dt-bootstrap">
                   <table class="table table-bordered table-striped table-hover dataTable js-exportable" >
                       <thead>
                       <tr role="row">
                           <th>
                               STT
                           </th>
                           <th>
                               Tên Thành Viên
                           </th>
                           <th>
                               Email
                           </th>
                           <th>
                               Phone
                           </th>
                           <th>
                               Password
                           </th>
                           <th>
                               Địa Chỉ
                           </th>
                           <th class="text-center">
                               Tác Vụ
                           </th>
                       </tr>
                       </thead>
                       <tbody>
                       <?php $__empty_1 = true; $__currentLoopData = $member; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$mem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                           <tr class="odd">
                               <td>
                                   <?php echo e($key); ?>

                               </td>
                               <td>
                                   <?php echo e($mem->name); ?>

                               </td>
                               <td>
                                   <?php echo e($mem->email); ?>

                               </td>
                               <td>
                                   <?php echo e($mem->phone); ?>

                               </td>
                               <td>
                                   <?php echo e($mem->password); ?>

                               </td>
                               <td>
                                   <?php echo e($mem->address); ?>

                               </td>
                               <td class="text-center">
                                   <a class="btn btn-primary waves-effect btn-action" href="<?php echo e(route('editmem',$mem->id)); ?>" role="button" title="Sửa">
                                       <i class="fa fa-edit"></i>
                                   </a>
                                   <a class="btn btn-danger waves-effect btn-action" href="<?php echo e(route('deletemem',$mem->id)); ?>" role="button" title="Xóa">
                                       <i class="fa fa-trash" aria-hidden="true"></i>
                                   </a>
                               </td>
                           </tr>
                       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                           <td colspan="4" class="text-center">Không tìm thấy dữ liệu.</td>
                       <?php endif; ?>
                       </tbody>
                   </table>
                   <!-- pagination -->

               </div>
           </div>
       </div>
    </div>	<!--/.main-->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xamppp\htdocs\demoshop\resources\views/backend/member.blade.php ENDPATH**/ ?>