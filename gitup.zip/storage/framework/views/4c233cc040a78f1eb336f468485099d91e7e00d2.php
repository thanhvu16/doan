<?php $__env->startSection('title','Thành Viên'); ?>
<?php $__env->startSection('main'); ?>

    <div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main" style="margin-top: 40px">

        <fieldset class="feildset-form">
            <legend>Chi Tiết Đơn Hàng</legend>
            <?php if($message = Session::get('success')): ?>
                <div class="alert alert-success">
                    <strong><?php echo e($message); ?></strong>
                </div>
            <?php endif; ?>
            <div class="table-responsive">
                <div  class="dataTables_wrapper form-inline dt-bootstrap">
                    <table class="table table-bordered table-striped table-hover dataTable js-exportable" >
                        <colgroup width="100%">
                            <col style="width: 5%;">
                            <col style="width: 40%;">
                            <col style="width: 25%;">
                            <col style="width: 30%;">

                        </colgroup>
                        <thead>
                        <tr role="row">
                            <th class="text-center">
                                STT
                            </th>
                            <th>
                                Tên Sản Phẩm
                            </th>
                            <th>
                                Số Lượng
                            </th>
                            <th>
                                Giá Tiền
                            </th>

                        </tr>
                        </thead>
                        <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $donhang; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr class="odd">
                                <td class="text-center">
                                    <?php echo e($key+1); ?>

                                </td>
                                <td>
                                    <?php echo e($data->name_sp); ?>

                                </td>
                                <td>
                                    <?php echo e($data->sl); ?>

                                </td>
                                <td>
                                    <?php echo e(number_format($data->total,0,',','.')); ?>đ
                                </td>

                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            </tr>

                            <td colspan="4" class="text-center">Không tìm thấy dữ liệu.</td>
                        <?php endif; ?>
                        </tbody>
                    </table>
                    <!-- pagination -->

                </div>
            </div>
            <div class="buttons-holder text-right">
                <a class="simple-link block" href="<?php echo e(route('getorder')); ?>" >Quay lại</a>
            </div>
        </fieldset>
    </div>  <!--/.main-->


<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xamppp\htdocs\gitup\resources\views/backend/Sanphamoder.blade.php ENDPATH**/ ?>